<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$result = $conn->query("SELECT * FROM poses WHERE status = 1 LIMIT 1");
if ($row = $result->fetch_assoc()) {
    echo implode(", ", [$row['motor1'], $row['motor2'], $row['motor3'], $row['motor4'], $row['motor5'], $row['motor6']]);
} else {
    echo "No active pose found.";
}
?>
