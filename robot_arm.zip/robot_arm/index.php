<?php
$host = "localhost";
$user = "root"; 
$pass = "";
$dbname = "robot_arm";

$conn = new mysqli($host, $user, $pass, $dbname);
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$result = $conn->query("SELECT * FROM poses");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Robot Arm Control Panel</title>
<style>
    body { font-family: Arial, sans-serif; text-align: center; }
    .slider { width: 300px; }
    table { margin: 20px auto; border-collapse: collapse; width: 80%; }
    th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
    button { padding: 5px 10px; }
</style>
</head>
<body>
<h2>Robot Arm Control Panel</h2>

<form method="POST" action="save_pose.php">
    <?php for ($i = 1; $i <= 6; $i++): ?>
        Motor <?= $i ?>:
        <input type="range" name="motor<?= $i ?>" min="0" max="180" value="90" 
               class="slider" oninput="this.nextElementSibling.value = this.value">
        <output>90</output><br><br>
    <?php endfor; ?>
    <button type="reset">Reset</button>
    <button type="submit" name="save">Save Pose</button>
    <button type="button" onclick="runPose()">Run</button>
</form>

<h3>Saved Poses</h3>
<table>
<tr>
    <th>#</th><th>Motor 1</th><th>Motor 2</th><th>Motor 3</th>
    <th>Motor 4</th><th>Motor 5</th><th>Motor 6</th><th>Action</th>
</tr>
<?php while($row = $result->fetch_assoc()): ?>
<tr>
    <td><?= $row['id'] ?></td>
    <?php for ($i=1; $i<=6; $i++): ?>
        <td><?= $row["motor$i"] ?></td>
    <?php endfor; ?>
    <td>
        <button onclick="loadPose(<?= $row['id'] ?>)">Load</button>
        <a href="remove_pose.php?id=<?= $row['id'] ?>"><button type="button">Remove</button></a>
    </td>
</tr>
<?php endwhile; ?>
</table>

<script>
function runPose() {
    fetch('get_run_pose.php')
        .then(response => response.text())
        .then(data => alert("Running Pose:\n" + data));
}
function loadPose(id) {
    window.location = "load_pose.php?id=" + id;
}
</script>
</body>
</html>
