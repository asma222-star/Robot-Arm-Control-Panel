<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'];

// Set all to inactive first
$conn->query("UPDATE poses SET status = 0");
// Activate only the selected pose
$conn->query("UPDATE poses SET status = 1 WHERE id = $id");

header("Location: index.php");
exit();
?>
