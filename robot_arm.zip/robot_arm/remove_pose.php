<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'];
$conn->query("DELETE FROM poses WHERE id = $id");

header("Location: index.php");
exit();
?>
