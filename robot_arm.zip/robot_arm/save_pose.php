<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if (isset($_POST['save'])) {
    $motors = [];
    for ($i = 1; $i <= 6; $i++) {
        $motors[$i] = $_POST["motor$i"];
    }

    $stmt = $conn->prepare("INSERT INTO poses (motor1, motor2, motor3, motor4, motor5, motor6) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iiiiii", $motors[1], $motors[2], $motors[3], $motors[4], $motors[5], $motors[6]);
    $stmt->execute();

    header("Location: index.php");
    exit();
}
?>
