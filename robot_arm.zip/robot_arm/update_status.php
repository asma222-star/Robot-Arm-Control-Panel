<?php
$conn = new mysqli("localhost", "root", "", "robot_arm");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$id = $_GET['id'];
$conn->query("UPDATE poses SET status = 0 WHERE id = $id");
header("Location: index.php");
?>
